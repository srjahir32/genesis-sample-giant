<?php

/**
 * Include the TGM_Plugin_Activation class.
 */
require_once dirname( __FILE__ ) . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );


function my_theme_register_required_plugins() {


	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => 'WPBakery Page Builder',
			'slug'               => 'js_composer',
			'source'             => get_stylesheet_directory() . '/config/tgmpa/plugin/js_composer.zip',
			'required'           => true,
			'version'            => '',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => '',
			'is_callable'        => '',
        ),
        
        array(
			'name'               => 'Slider Revolution',
			'slug'               => 'revslider',
			'source'             => get_stylesheet_directory() . '/config/tgmpa/plugin/revslider.zip',
			'required'           => true,
			'version'            => '',
			'force_activation'   => false,
			'force_deactivation' => false,
			'external_url'       => '',
			'is_callable'        => '',
		),


	);


	$config = array(
		'id'           => 'tgmpa',          
		'default_path' => '',           
		'menu'         => 'tgmpa-install-plugins',
		'parent_slug'  => 'themes.php',    
		'capability'   => 'edit_theme_options',
		'has_notices'  => true,          
		'dismissable'  => true,            
		'dismiss_msg'  => '',             
		'is_automatic' => true,             
		'message'      => '',               

	);

	tgmpa( $plugins, $config );

}

?>